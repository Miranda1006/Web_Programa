const express = require('express');
const app = express();

app.set('view engine', 'ejs'); // Configuração da engine de templates para EJS
app.set('views', './views'); // Definição do diretório onde suas views ficam

//NÃO CONSEGUI RODAR O SITE MAS FIZ TUDO QUE FOI MANDADO,
//ATÉ INSTALEI O PACOTE "EJS" POR SER MAIS FACIL MAS MESMO ASSIM O ERRO CONTINUOU


// Configurar a pasta de views
app.set('views', './views');

// Rota para exibir o formulário de cadastro
app.get('/', (req, res) => {
  res.render('index');
});

// Rota para processar o formulário e exibir os produtos
app.post('/add-product', (req, res) => {
  res.render('products', { /* Enviae os dados dos produtos cadastrados para esta página */ });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server Aberto na porta ${PORT}`);
});
